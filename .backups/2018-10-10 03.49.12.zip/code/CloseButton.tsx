import * as React from 'react'
import { PropertyControls, ControlType } from 'framer'
import styled, { css } from 'styled-components'

const Wrap = styled.div`
  ${props =>
    props.src &&
    css`
      background: center / cover no-repeat url(${props.src});
    `};
`

const Child = styled.div``

// Define type of property
interface Props {
  text: string
}

export class CloseButton extends React.Component<Props> {
  // Set default properties
  static defaultProps = {
    text: 'Hello World!',
    children: null,
    mainImg: 'http://kaijupop.com/wp-content/uploads/2014/04/KWsub.png',
  }

  // Items shown in property panel
  static propertyControls: PropertyControls = {
    text: { type: ControlType.String, title: 'Text' },
    children: { type: ControlType.Children, title: 'Children' },
    mainImg: { type: ControlType.String, title: 'Main Image' },
  }

  render() {
    return (
      <Wrap src={this.props.mainImg}>
        <Child>{this.props.children}</Child>
      </Wrap>
    )
  }
}
